package com.portfolio.ejp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjpApplicationTests {

	@Test
	void contextLoads() {
	}

}
